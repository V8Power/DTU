/*
 * timer.h
 *
 * Created: 06-01-2023 13:00:58
 *  Author: Abdel, SAAD
 */ 


extern void init_timer();