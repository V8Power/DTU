/*
 * checksum_cal.c
 *
 * Created: 12-01-2023 15:28:21
 *  Author: Abdel
 */ 






