/*
 * ADC.h
 *
 * Created: 06-01-2023 13:12:20
 *  Author: Abdel, SAAD
 */ 

extern void init_ADC();
